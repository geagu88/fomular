document.getElementById("formular").addEventListener("submit", function(event) {
    event.preventDefault();
    var formData = new FormData(this);
    var table = '<table border="1">';
    table += '<thead><tr><th>Nr. crt.</th><th>Grad</th><th>Nume</th><th>Prenume</th><th>Structura</th><th>CNP</th><th>Seria PC</th><th>Data expirării PC</th><th>Semnatura</th></tr></thead><tbody>';
    table += '<tr>';
    table += '<td>' + formData.get('Nr. crt.') + '</td>';
    table += '<td>' + formData.get('grad') + '</td>';
    table += '<td>' + formData.get('nume') + '</td>';
    table += '<td>' + formData.get('prenume') + '</td>';
    table += '<td>' + formData.get('structura') + '</td>';
    table += '<td>' + formData.get('cnp') + '</td>';
    table += '<td>' + formData.get('seria_pc') + '</td>';
    table += '<td>' + formData.get('data_expirarii') + '</td>';
    table += '<td>' + formData.get('semnatura') + '</td>';
    table += '</tr>';
    table += '</tbody></table>';
    document.getElementById("tabelRezultat").innerHTML += table;
});
